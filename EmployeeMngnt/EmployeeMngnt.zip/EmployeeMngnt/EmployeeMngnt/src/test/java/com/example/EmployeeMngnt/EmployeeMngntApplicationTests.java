package com.example.EmployeeMngnt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeMngntApplicationTests {

	@Test
	void contextLoads() {
	}

}
