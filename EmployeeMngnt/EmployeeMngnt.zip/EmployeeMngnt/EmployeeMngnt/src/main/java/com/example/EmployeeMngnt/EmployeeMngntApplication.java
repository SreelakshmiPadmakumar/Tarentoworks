package com.example.EmployeeMngnt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeMngntApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeMngntApplication.class, args);
	}

}
